from pathlib import Path
PACKAGE_BASE_PATH = Path(__file__).parent
